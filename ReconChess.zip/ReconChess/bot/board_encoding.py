import chess
import torch
from util import generate_board, Engine
import pickle
import pandas as pd
import time
import os


def generate_dataset(N=3):
    if os.path.exists('data.pkl'):
        old = pd.read_pickle('data.pkl')
    else:
        old = pd.DataFrame({'board': [], 'solution': [], 'date_generated': []})
    engine = Engine()
    data = []
    for i in range(N):
        tensor, fen = generate_board()
        move = engine.play(fen)
        if move is not None:
            data.append((tensor, move, time.time()))
            print(f"generated i = {i}")
    engine.stop_engine()
    print('getting data ready to save')
    X, Y, date = list(zip(*data))
    df = pd.DataFrame({'board': X, 'solution': Y, 'date_generated': date})
    df = pd.concat([old, df])
    print('saving data...')
    df.to_pickle('data.pkl')
    exit()


generate_dataset(10000)
