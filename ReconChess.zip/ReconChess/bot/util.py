import random

import chess
import chess.engine
from sklearn import preprocessing
import torch
import numpy as np

piece_list = ["R", "N", "B", "Q", "P"]


def place_kings(brd):
    while True:
        rank_white, file_white, rank_black, file_black = random.randint(0, 7), random.randint(0, 7), random.randint(0,
                                                                                                                    7), random.randint(
            0, 7)
        diff_list = [abs(rank_white - rank_black), abs(file_white - file_black)]
        if sum(diff_list) > 2 or set(diff_list) == {0, 2}:
            brd[rank_white][file_white], brd[rank_black][file_black] = "K", "k"
            break


def populate_board(brd, wp, bp):
    for x in range(2):
        if x == 0:
            piece_amount = wp
            pieces = piece_list
        else:
            piece_amount = bp
            pieces = [s.lower() for s in piece_list]
        while piece_amount != 0:
            piece_rank, piece_file = random.randint(0, 7), random.randint(0, 7)
            piece = random.choice(pieces)
            if brd[piece_rank][piece_file] == " " and pawn_on_promotion_square(piece, piece_rank) == False:
                brd[piece_rank][piece_file] = piece
                piece_amount -= 1


def fen_from_board(brd):
    fen = ""
    for x in brd:
        n = 0
        for y in x:
            if y == " ":
                n += 1
            else:
                if n != 0:
                    fen += str(n)
                fen += y
                n = 0
        if n != 0:
            fen += str(n)
        fen += "/" if fen.count("/") < 7 else ""
    return fen


def pawn_on_promotion_square(pc, pr):
    if pc == "P" and pr == 0:
        return True
    elif pc == "p" and pr == 7:
        return True
    return False


def generate_board():
    board = [[" " for x in range(8)] for y in range(8)]

    piece_amount_white, piece_amount_black = random.randint(0, 15), random.randint(0, 15)
    place_kings(board)
    populate_board(board, piece_amount_white, piece_amount_black)

    le = preprocessing.LabelEncoder()
    encoding = le.fit_transform(np.array(board).flatten())
    encoding = encoding.reshape(8, 8)
    return encoding, fen_from_board(board)


def convert_uci_move_to_matrix(move):
    move = str(move)
    a = move[:2]
    b = move[2:4]
    a = str(ord(a[0]) - ord('a')) + a[1]
    b = str(ord(b[0]) - ord('a')) + b[1]
    promotion = move[-1] if len(move) == 5 else None
    start = int(a[0]), int(a[1])
    direction = None
    # calculate direction
    dh = int(b[1]) - int(a[1])
    dv = int(b[0]) - int(a[0])

    # for readability, cases:
    if dh == 0 and dv > 0:  # up
        direction = 0
    elif dh == 0 and dv < 0:  # down
        direction = 1
    elif dh > 0 and dv == 0:  # right
        direction = 2
    elif dh < 0 and dv == 0:  # left
        direction = 3
    elif abs(dh) != abs(dv):  # knight
        direction = 8
    elif dh > 0 and dv > 0:  # upper right
        direction = 4
    elif dh > 0 and dv < 0:  # lower right
        direction = 5
    elif dh < 0 and dv > 0:  # upper left
        direction = 6
    elif dh < 0 and dv < 0:  # lower left
        direction = 7

    if direction == 8:
        move_idx = 4 * int(dv > 0) + 2 * int(dh > 0) + int(abs(dh) > abs(dv))
    else:
        move_idx = abs(dh) if abs(dh) > 0 else abs(dv)
    idx = 7 * direction + move_idx

    if promotion is None:
        encoding = *start, idx
    else:
        direction = None
        if abs(dh) > 0:
            direction = 0
        elif abs(dh) == 0:
            direction = 1
        elif abs(dh) < 0:
            direction = 2

        if promotion == 'k':
            move_idx = 0
        elif promotion == 'b':
            move_idx = 1
        else:
            move_idx = 2

        idx = 64 + 3 * direction + move_idx
        encoding = *start, idx

    return 64 * encoding[2] + 8 * encoding[0] + encoding[1]

class Engine:
    STOCKFISH_PATH = '/usr/local/Cellar/stockfish/14.1/bin/stockfish'

    def __init__(self):
        self.engine = None
        self.restart_engine()

    def restart_engine(self):
        self.engine = chess.engine.SimpleEngine.popen_uci(self.STOCKFISH_PATH, setpgrp=True)

    def play(self, fen):
        board = chess.Board()
        try:
            board.set_board_fen(fen)
            result = self.engine.play(board, chess.engine.Limit(time=0.55))
            return convert_uci_move_to_matrix(result.move)
        except:
            self.restart_engine()
            print("Engine died!")
            return None

    def stop_engine(self):
        self.engine.quit()
